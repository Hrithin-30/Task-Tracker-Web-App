import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || '/api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 10000
});

// Response interceptor for global error handling
api.interceptors.response.use(
  response => response,
  error => {
    const message =
      error.response?.data?.error ||
      error.response?.data?.message ||
      error.message ||
      'An unexpected error occurred';
    return Promise.reject(new Error(message));
  }
);

export const taskService = {
  // Fetch tasks with optional filters
  getTasks: (params = {}) =>
    api.get('/tasks', { params }).then(r => r.data),

  // Get aggregated stats
  getStats: () =>
    api.get('/tasks/stats').then(r => r.data),

  // Get single task by ID
  getTask: (id) =>
    api.get(`/tasks/${id}`).then(r => r.data),

  // Create a new task
  createTask: (data) =>
    api.post('/tasks', data).then(r => r.data),

  // Full update
  updateTask: (id, data) =>
    api.put(`/tasks/${id}`, data).then(r => r.data),

  // Partial update (e.g. status toggle)
  patchTask: (id, data) =>
    api.patch(`/tasks/${id}`, data).then(r => r.data),

  // Delete single task
  deleteTask: (id) =>
    api.delete(`/tasks/${id}`).then(r => r.data),

  // Bulk delete
  bulkDelete: (ids) =>
    api.delete('/tasks', { data: { ids } }).then(r => r.data)
};

export default api;