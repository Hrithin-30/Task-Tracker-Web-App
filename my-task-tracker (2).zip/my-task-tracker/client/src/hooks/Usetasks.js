import { useState, useEffect, useCallback } from 'react';
import { taskService } from '../services/taskService';
import toast from 'react-hot-toast';

export function useTasks() {
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    status: 'all',
    priority: 'all',
    search: '',
    sortBy: 'createdAt',
    order: 'desc'
  });

  const fetchTasks = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const params = {};
      if (filters.status !== 'all') params.status = filters.status;
      if (filters.priority !== 'all') params.priority = filters.priority;
      if (filters.search) params.search = filters.search;
      params.sortBy = filters.sortBy;
      params.order = filters.order;

      const [data, statsData] = await Promise.all([
        taskService.getTasks(params),
        taskService.getStats()
      ]);
      setTasks(data.tasks);
      setStats(statsData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const createTask = async (formData) => {
    setSubmitting(true);
    try {
      const newTask = await taskService.createTask(formData);
      setTasks(prev => [newTask, ...prev]);
      setStats(prev => prev ? {
        ...prev,
        total: prev.total + 1,
        byStatus: { ...prev.byStatus, [newTask.status]: (prev.byStatus[newTask.status] || 0) + 1 }
      } : prev);
      toast.success('Task created!');
      return { success: true };
    } catch (err) {
      toast.error(err.message);
      return { success: false, error: err.message };
    } finally {
      setSubmitting(false);
    }
  };

  const updateTask = async (id, formData) => {
    setSubmitting(true);
    try {
      const updated = await taskService.updateTask(id, formData);
      setTasks(prev => prev.map(t => t._id === id ? updated : t));
      toast.success('Task updated!');
      fetchTasks(); // refresh stats
      return { success: true };
    } catch (err) {
      toast.error(err.message);
      return { success: false, error: err.message };
    } finally {
      setSubmitting(false);
    }
  };

  const patchTask = async (id, data) => {
    try {
      const updated = await taskService.patchTask(id, data);
      setTasks(prev => prev.map(t => t._id === id ? updated : t));
      fetchTasks(); // refresh stats
      return { success: true };
    } catch (err) {
      toast.error(err.message);
      return { success: false };
    }
  };

  const deleteTask = async (id) => {
    try {
      await taskService.deleteTask(id);
      setTasks(prev => prev.filter(t => t._id !== id));
      toast.success('Task deleted');
      fetchTasks();
      return { success: true };
    } catch (err) {
      toast.error(err.message);
      return { success: false };
    }
  };

  const updateFilters = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  return {
    tasks,
    stats,
    loading,
    submitting,
    error,
    filters,
    updateFilters,
    createTask,
    updateTask,
    patchTask,
    deleteTask,
    refetch: fetchTasks
  };
}