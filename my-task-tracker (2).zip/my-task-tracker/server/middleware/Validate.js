// Validates task create/update request body
const validateTask = (req, res, next) => {
  const { title, status, priority, dueDate } = req.body;
  const errors = {};

  // Title validation (required on create, optional on partial update)
  if (req.method === 'POST' || title !== undefined) {
    if (!title || typeof title !== 'string' || title.trim().length < 3) {
      errors.title = 'Title must be at least 3 characters';
    } else if (title.trim().length > 100) {
      errors.title = 'Title cannot exceed 100 characters';
    }
  }

  // Status validation
  const validStatuses = ['todo', 'in-progress', 'completed'];
  if (status && !validStatuses.includes(status)) {
    errors.status = 'Status must be todo, in-progress, or completed';
  }

  // Priority validation
  const validPriorities = ['low', 'medium', 'high'];
  if (priority && !validPriorities.includes(priority)) {
    errors.priority = 'Priority must be low, medium, or high';
  }

  // Due date validation
  if (dueDate && isNaN(new Date(dueDate).getTime())) {
    errors.dueDate = 'Invalid date format';
  }

  if (Object.keys(errors).length > 0) {
    return res.status(400).json({ errors });
  }

  next();
};

module.exports = { validateTask };